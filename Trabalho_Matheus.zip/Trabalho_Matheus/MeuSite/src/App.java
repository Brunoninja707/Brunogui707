import models.Pessoa; // Adicione esta linha no início de App.java

public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");

        // Exemplo de uso de Pessoa
        Pessoa pessoa1 = new Pessoa("Fulano", 30, "Rua X, 123", "11122233344");
        pessoa1.exibirInformacoes();

        // Ou usando o toString()
        System.out.println(pessoa1);
    }
}