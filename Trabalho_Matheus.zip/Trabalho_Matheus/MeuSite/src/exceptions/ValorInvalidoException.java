package exceptions;

/**
 * Exceção lançada quando um valor numérico fornecido para uma operação
 * é considerado inválido (por exemplo, negativo, zero ou fora de um limite esperado).
 */
public class ValorInvalidoException extends Exception { // Herda de Exception (Checked Exception)

    /**
     * Construtor que aceita uma mensagem detalhando o erro.
     * @param message A mensagem explicando por que o valor é inválido.
     */
    public ValorInvalidoException(String message) {
        super(message); // Passa a mensagem para o construtor da classe pai (Exception)
    }

    /**
     * Construtor padrão (opcional).
     */
    public ValorInvalidoException() {
        super("O valor fornecido é inválido para esta operação.");
    }
}