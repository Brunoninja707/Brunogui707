package exceptions;

/**
 * Exceção lançada quando uma operação (como saque) não pode ser concluída
 * porque o saldo da conta é insuficiente.
 */
public class SaldoInsuficienteException extends Exception { // Herda de Exception (Checked Exception)

    /**
     * Construtor que aceita uma mensagem detalhando o erro.
     * @param message A mensagem explicando a insuficiência de saldo.
     */
    public SaldoInsuficienteException(String message) {
        super(message); // Passa a mensagem para o construtor da classe pai (Exception)
    }

     /**
     * Construtor padrão (opcional).
     */
    public SaldoInsuficienteException() {
        super("Saldo insuficiente para realizar a operação.");
    }

    /**
     * Construtor (opcional) que pode incluir o saldo atual e o valor tentado.
     * @param saldoAtual O saldo disponível no momento da tentativa.
     * @param valorTentado O valor que se tentou operar (ex: sacar).
     */
    public SaldoInsuficienteException(double saldoAtual, double valorTentado) {
        super("Saldo insuficiente. Saldo atual: R$" + String.format("%.2f", saldoAtual) +
              ", Valor tentado: R$" + String.format("%.2f", valorTentado));
    }
}