package interfaces; // Ou 'package models;' se preferir colocar na mesma pasta

/**
 * Interface para objetos que podem ser tributados, ou seja,
 * sobre os quais pode ser calculado um imposto (como o Imposto de Renda).
 */
public interface Tributavel {

    /**
     * Calcula o valor do imposto devido pelo objeto.
     * A lógica específica do cálculo dependerá da classe que implementa esta interface.
     *
     * @return O valor do imposto calculado (geralmente um valor double).
     */
    double calculaIR(); // Por padrão, métodos em interfaces são public abstract

}