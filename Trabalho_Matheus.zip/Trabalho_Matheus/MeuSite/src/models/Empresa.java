package models;

import exceptions.ValorInvalidoException; // Para usar no pagarFuncionarios

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * Representa a Empresa que gerencia funcionários, produtos e e-mails.
 */
public class Empresa {

    // Atributos usando convenção Java (lowercase)
    private String nome;
    private String cnpj;
    private List<String> emails; // Máximo 5
    private List<Funcionario> funcionarios;
    private Map<Integer, Produto> produtos; // Usando código (Integer) como chave

    private static final int MAX_EMAILS = 5;

    /**
     * Construtor da Empresa.
     *
     * @param nome Nome da empresa.
     * @param cnpj CNPJ da empresa.
     */
    public Empresa(String nome, String cnpj) {
        this.nome = nome;
        // Adicionar validação de CNPJ se necessário
        this.cnpj = cnpj;
        // Inicializa as coleções
        this.emails = new ArrayList<>();
        this.funcionarios = new ArrayList<>();
        this.produtos = new HashMap<>();
    }

    // --- Getters e Setters Básicos ---
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCnpj() {
        return cnpj;
    }

    // CNPJ geralmente não muda, mas pode ter setter se necessário (com validação)
    // public void setCnpj(String cnpj) { this.cnpj = cnpj; }
    // --- Gerenciamento de E-mails (com limite) ---
    /**
     * Adiciona um e-mail à lista da empresa, se o limite não foi atingido.
     *
     * @param email O e-mail a ser adicionado.
     * @return true se o e-mail foi adicionado, false caso contrário (limite
     * atingido ou e-mail inválido/duplicado).
     */
    public boolean adicionarEmail(String email) {
        // Validação simples de e-mail e duplicidade
        if (email == null || email.isEmpty() || !email.contains("@") || emails.contains(email)) {
            System.out.println("Erro: E-mail inválido ou já existente.");
            return false;
        }
        if (this.emails.size() < MAX_EMAILS) {
            this.emails.add(email);
            System.out.println("E-mail '" + email + "' adicionado.");
            return true;
        } else {
            System.out.println("Erro: Limite máximo de " + MAX_EMAILS + " e-mails atingido.");
            return false;
        }
    }

    /**
     * Remove um e-mail da lista da empresa.
     *
     * @param email O e-mail a ser removido.
     * @return true se o e-mail foi removido, false caso contrário (não
     * encontrado).
     */
    public boolean removerEmail(String email) {
        boolean removido = this.emails.remove(email);
        if (removido) {
            System.out.println("E-mail '" + email + "' removido.");
        } else {
            System.out.println("Erro: E-mail '" + email + "' não encontrado para remoção.");
        }
        return removido;
    }

    /**
     * Exibe todos os e-mails cadastrados da empresa.
     */
    public void exibirEmails() {
        System.out.println("--- E-mails da Empresa: " + this.nome + " ---");
        if (this.emails.isEmpty()) {
            System.out.println("Nenhum e-mail cadastrado.");
        } else {
            this.emails.forEach(System.out::println);
        }
        System.out.println("-------------------------------------");
    }

    // Retorna uma cópia não modificável da lista de e-mails
    public List<String> getEmails() {
        return List.copyOf(this.emails); // Retorna visão não modificável
    }

    // --- Gerenciamento de Funcionários ---
    // Idealmente, mover para FuncionarioService
    /**
     * Adiciona um funcionário à lista da empresa.
     *
     * @param funcionario O funcionário a ser adicionado.
     * @return true se adicionado com sucesso (após validações básicas).
     */
    public boolean adicionarFuncionario(Funcionario funcionario) {
        if (funcionario == null || funcionario.getCpf() == null) {
            System.out.println("Erro: Funcionário inválido.");
            return false;
        }
        // Evitar duplicidade por CPF
        if (funcionarios.stream().anyMatch(f -> f.getCpf().equals(funcionario.getCpf()))) {
            System.out.println("Erro: Funcionário com CPF " + funcionario.getCpf() + " já cadastrado.");
            return false;
        }
        this.funcionarios.add(funcionario);
        System.out.println("Funcionário " + funcionario.getNome() + " adicionado.");
        return true;
    }

    /**
     * Remove um funcionário da lista pelo CPF.
     *
     * @param cpf O CPF do funcionário a ser removido.
     * @return true se removido, false se não encontrado.
     */
    public boolean removerFuncionario(String cpf) {
        boolean removido = this.funcionarios.removeIf(f -> f.getCpf().equals(cpf));
        if (removido) {
            System.out.println("Funcionário com CPF " + cpf + " removido.");
        } else {
            System.out.println("Erro: Funcionário com CPF " + cpf + " não encontrado para remoção.");
        }
        return removido;
    }

    /**
     * Exibe as informações de todos os funcionários da empresa.
     */
    public void exibirFuncionarios() {
        System.out.println("--- Funcionários da Empresa: " + this.nome + " ---");
        if (this.funcionarios.isEmpty()) {
            System.out.println("Nenhum funcionário cadastrado.");
        } else {
            this.funcionarios.forEach(Funcionario::exibirInformacoes); // Usa o método do próprio funcionário
        }
        System.out.println("-----------------------------------------");
    }

    // Retorna uma cópia não modificável da lista de funcionários
    public List<Funcionario> getFuncionarios() {
        return List.copyOf(this.funcionarios);
    }

    // --- Gerenciamento de Produtos ---
    // Idealmente, mover para ProdutoService
    /**
     * Adiciona ou atualiza um produto no mapa da empresa. Se o código já
     * existe, atualiza o produto; senão, adiciona.
     *
     * @param produto O produto a ser adicionado/atualizado.
     * @return true se a operação foi bem-sucedida.
     */
    public boolean adicionarOuAtualizarProduto(Produto produto) {
        if (produto == null || produto.getCodigo() <= 0) {
            System.out.println("Erro: Produto inválido.");
            return false;
        }
        this.produtos.put(produto.getCodigo(), produto); // put substitui se a chave já existir
        System.out.println("Produto " + produto.getNome() + " (Cód: " + produto.getCodigo() + ") adicionado/atualizado.");
        return true;
    }

    /**
     * Remove um produto do mapa pelo código.
     *
     * @param codigo O código do produto a ser removido.
     * @return O objeto Produto removido, ou null se não encontrado.
     */
    public Produto removerProduto(int codigo) {
        Produto removido = this.produtos.remove(codigo);
        if (removido != null) {
            System.out.println("Produto " + removido.getNome() + " (Cód: " + codigo + ") removido.");
        } else {
            System.out.println("Erro: Produto com código " + codigo + " não encontrado para remoção.");
        }
        return removido;
    }

    /**
     * Exibe todos os produtos cadastrados na empresa.
     */
    public void exibirProdutos() {
        System.out.println("--- Produtos da Empresa: " + this.nome + " ---");
        if (this.produtos.isEmpty()) {
            System.out.println("Nenhum produto cadastrado.");
        } else {
            // Imprime cada produto (usando o toString da classe Produto)
            this.produtos.values().forEach(System.out::println);
        }
        System.out.println("-------------------------------------");
    }

    // Retorna uma cópia não modificável do mapa de produtos
    public Map<Integer, Produto> getProdutos() {
        return Map.copyOf(this.produtos);
    }

    // --- Busca de Produtos (com Stream API) ---
    /**
     * Busca produtos pelo nome (contendo a string fornecida, case-insensitive).
     *
     * @param nomeBusca Parte do nome a ser buscado.
     * @return Uma lista de produtos que correspondem ao critério.
     */
    public List<Produto> buscarProdutoPorNome(String nomeBusca) {
        if (nomeBusca == null || nomeBusca.trim().isEmpty()) {
            return new ArrayList<>(); // Retorna lista vazia se busca for inválida
        }
        String nomeBuscaLower = nomeBusca.toLowerCase();
        return this.produtos.values().stream()
                .filter(p -> p.getNome().toLowerCase().contains(nomeBuscaLower))
                .collect(Collectors.toList());
    }

    /**
     * Busca um produto pelo código exato.
     *
     * @param codigoBusca O código do produto.
     * @return Um Optional contendo o produto se encontrado, ou Optional vazio.
     */
    public Optional<Produto> buscarProdutoPorCodigo(int codigoBusca) {
        // O método get do HashMap é mais eficiente para busca por chave exata
        return Optional.ofNullable(this.produtos.get(codigoBusca));
    }

    /**
     * Busca produtos dentro de uma faixa de preço.
     *
     * @param precoMin Preço mínimo (inclusive).
     * @param precoMax Preço máximo (inclusive).
     * @return Uma lista de produtos que correspondem ao critério.
     */
    public List<Produto> buscarProdutoPorPreco(double precoMin, double precoMax) {
        if (precoMin < 0 || precoMax < 0 || precoMin > precoMax) {
            System.out.println("Erro: Faixa de preço inválida.");
            return new ArrayList<>();
        }
        return this.produtos.values().stream()
                .filter(p -> p.getValor() >= precoMin && p.getValor() <= precoMax)
                .collect(Collectors.toList());
    }

    // --- Pagamento de Funcionários ---
    // Idealmente, mover para FolhaPagamentoService ou similar
    /**
     * Percorre a lista de funcionários e tenta depositar o salário na
     * contaSalario de cada um.
     */
    public void pagarFuncionarios() {
        System.out.println("\n--- Iniciando Processamento da Folha de Pagamento ---");
        if (this.funcionarios.isEmpty()) {
            System.out.println("Nenhum funcionário para pagar.");
            return;
        }

        for (Funcionario f : this.funcionarios) {
            double salario = f.getSalario();
            ContaBancaria conta = f.getContaSalario();

            if (conta == null) {
                System.err.println("Erro: Funcionário " + f.getNome() + " (CPF: " + f.getCpf() + ") não possui conta salário definida.");
                continue; // Pula para o próximo funcionário
            }

            if (salario <= 0) {
                System.out.println("Aviso: Salário do funcionário " + f.getNome() + " é zero ou negativo. Nenhum depósito realizado.");
                continue; // Pula para o próximo funcionário
            }

            try {
                // Tenta depositar o salário
                conta.depositar(salario);
                System.out.println("Pagamento de R$" + String.format("%.2f", salario)
                        + " efetuado para " + f.getNome()
                        + " na conta " + conta.getConta());
            } catch (ValorInvalidoException e) {
                // Embora depositar valide > 0, é bom ter o catch por robustez
                System.err.println("Erro de VALOR INVÁLIDO ao tentar pagar funcionário " + f.getNome()
                        + " (Salário: R$" + String.format("%.2f", salario) + "): " + e.getMessage());
            } catch (Exception e) {
                // Captura outras exceções inesperadas que podem ocorrer no depósito
                System.err.println("Erro INESPERADO ao tentar pagar funcionário " + f.getNome() + ": " + e.getMessage());
            }
        }
        System.out.println("--- Folha de Pagamento Processada ---");
    }

    // --- toString() ---
    @Override
    public String toString() {
        return "Empresa{"
                + "nome='" + nome + '\''
                + ", cnpj='" + cnpj + '\''
                + ", emails=" + emails.size()
                + ", funcionarios=" + funcionarios.size()
                + ", produtos=" + produtos.size()
                + '}';
    }

    // --- equals() e hashCode() (Baseado no CNPJ) ---
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        Empresa empresa = (Empresa) o;
        return Objects.equals(cnpj, empresa.cnpj); // Empresas são iguais se tiverem o mesmo CNPJ
    }

    @Override
    public int hashCode() {
        return Objects.hash(cnpj); // HashCode baseado no CNPJ
    }
}
