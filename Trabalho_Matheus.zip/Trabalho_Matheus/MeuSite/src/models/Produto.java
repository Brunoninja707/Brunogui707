package models;

import java.util.Objects;

/**
 * Representa um produto comercializável pela empresa.
 */
public class Produto {

    // Atributos privados
    private int codigo; // Usando int para código, pode ser String se necessário
    private double valor;
    private String nome;
    private int quantidade; // Quantidade em estoque

    // Construtor padrão
    public Produto() {
    }

    // Construtor com todos os atributos
    public Produto(int codigo, String nome, double valor, int quantidade) {
        this.codigo = codigo;
        this.nome = nome;
        setValor(valor); // Usa o setter para possível validação
        setQuantidade(quantidade); // Usa o setter para possível validação
    }

    // --- Getters ---

    public int getCodigo() {
        return codigo;
    }

    public double getValor() {
        return valor;
    }

    public String getNome() {
        return nome;
    }

    public int getQuantidade() {
        return quantidade;
    }

    // --- Setters ---

    // Código pode não ser alterável após criado, dependendo da regra de negócio.
    // Se puder ser alterado, descomente o setter.
    // public void setCodigo(int codigo) {
    //     this.codigo = codigo;
    // }

    public void setValor(double valor) {
        if (valor >= 0) {
            this.valor = valor;
        } else {
            System.out.println("Erro: Valor do produto não pode ser negativo.");
            // Considerar lançar IllegalArgumentException
        }
    }

    public void setNome(String nome) {
        // Adicionar validação se nome não pode ser vazio/nulo, se necessário
        this.nome = nome;
    }

    public void setQuantidade(int quantidade) {
        if (quantidade >= 0) {
            this.quantidade = quantidade;
        } else {
            System.out.println("Erro: Quantidade do produto não pode ser negativa.");
            // Considerar lançar IllegalArgumentException
        }
    }

    // --- Métodos Adicionais (Opcional, mas útil) ---

    /**
     * Adiciona uma quantidade ao estoque do produto.
     * @param quantidadeParaAdicionar A quantidade a ser adicionada (deve ser positiva).
     */
    public void adicionarEstoque(int quantidadeParaAdicionar) {
        if (quantidadeParaAdicionar > 0) {
            this.quantidade += quantidadeParaAdicionar;
        } else {
             System.out.println("Erro: Quantidade a adicionar deve ser positiva.");
        }
    }

     /**
     * Remove uma quantidade do estoque do produto.
     * @param quantidadeParaRemover A quantidade a ser removida (deve ser positiva e não maior que o estoque atual).
     * @return true se a remoção foi bem-sucedida, false caso contrário.
     */
    public boolean removerEstoque(int quantidadeParaRemover) {
        if (quantidadeParaRemover <= 0) {
             System.out.println("Erro: Quantidade a remover deve ser positiva.");
             return false;
        }
        if (quantidadeParaRemover <= this.quantidade) {
            this.quantidade -= quantidadeParaRemover;
            return true;
        } else {
            System.out.println("Erro: Estoque insuficiente para remover " + quantidadeParaRemover + " unidades do produto '" + this.nome + "'.");
            return false;
        }
    }


    // --- toString(), equals() e hashCode() ---

    @Override
    public String toString() {
        return "Produto{" +
               "codigo=" + codigo +
               ", nome='" + nome + '\'' +
               ", valor=" + String.format("%.2f", valor) +
               ", quantidade=" + quantidade +
               '}';
    }

    /**
     * Dois produtos são considerados iguais se tiverem o mesmo código.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Produto produto = (Produto) o;
        return codigo == produto.codigo; // Comparando apenas pelo código
    }

    /**
     * O hashCode é baseado no código do produto.
     */
    @Override
    public int hashCode() {
        return Objects.hash(codigo); // Usando apenas o código para o hashCode
    }
}