package models;

import exceptions.SaldoInsuficienteException;
import exceptions.ValorInvalidoException;

/**
 * Representa uma Conta Corrente, que é um tipo de Conta Bancária.
 * Possui uma tarifa fixa que é cobrada a cada saque.
 */
public class ContaCorrente extends ContaBancaria {

    // Atributo estático para a tarifa de saque, compartilhado por todas as Contas Correntes.
    // Definindo um valor padrão inicial. Pode ser alterado com um setter estático se necessário.
    private static double tarifa = 1.25; // Exemplo: R$ 1,25 por saque

    /**
     * Construtor da Conta Corrente.
     * Repassa os dados básicos para o construtor da classe mãe (ContaBancaria).
     *
     * @param titular Nome do titular da conta.
     * @param conta Número da conta.
     * @param agencia Número da agência.
     * @param senha Senha da conta.
     */
    public ContaCorrente(String titular, String conta, String agencia, String senha) {
        super(titular, conta, agencia, senha); // Chama o construtor da ContaBancaria
    }

    // --- Getter e Setter para a tarifa estática (opcional, mas permite configurar a tarifa) ---

    public static double getTarifa() {
        return tarifa;
    }

    public static void setTarifa(double novaTarifa) {
        if (novaTarifa >= 0) {
            ContaCorrente.tarifa = novaTarifa;
        } else {
            System.out.println("Erro: Tarifa não pode ser negativa.");
        }
    }


    /**
     * Sobrescreve o método sacar da ContaBancaria para incluir a cobrança da tarifa.
     *
     * @param valor O valor que o cliente deseja sacar.
     * @throws SaldoInsuficienteException Se o saldo não for suficiente para cobrir o valor do saque mais a tarifa.
     * @throws ValorInvalidoException Se o valor do saque for negativo ou zero.
     */
    @Override
    public void sacar(double valor) throws SaldoInsuficienteException, ValorInvalidoException {
        // 1. Validar o valor do saque
        if (valor <= 0) {
            throw new ValorInvalidoException("Valor de saque inválido (R$" + String.format("%.2f", valor) + "). Deve ser maior que zero.");
        }

        // 2. Calcular o valor total a ser debitado (saque + tarifa)
        double valorTotalDebito = valor + tarifa;

        // 3. Verificar se há saldo suficiente
        if (valorTotalDebito > getSaldo()) {
            throw new SaldoInsuficienteException("Saldo insuficiente para saque de R$" + String.format("%.2f", valor) +
                                                 " (Custo total com tarifa: R$" + String.format("%.2f", valorTotalDebito) +
                                                 "). Saldo atual: R$" + String.format("%.2f", getSaldo()));
        }

        // 4. Realizar o saque (atualizar o saldo)
        // Usando o método protegido setSaldo herdado de ContaBancaria
        setSaldo(getSaldo() - valorTotalDebito);

        // 5. Imprimir confirmação e valor da tarifa (conforme solicitado)
        System.out.println("Saque de R$" + String.format("%.2f", valor) + " realizado com sucesso.");
        System.out.println("Tarifa de saque debitada: R$" + String.format("%.2f", tarifa));
        System.out.println("Valor total debitado: R$" + String.format("%.2f", valorTotalDebito));
        // Opcional: exibir o novo saldo
        // System.out.println("Novo saldo: R$" + String.format("%.2f", getSaldo()));
    }

    // O método toString() herdado de ContaBancaria já é adequado,
    // pois usamos getClass().getSimpleName() nele.
    // Se quiser adicionar a tarifa ao toString, pode sobrescrevê-lo aqui.
    /*
    @Override
    public String toString() {
        return super.toString() + " [Tarifa Padrão CC: R$" + String.format("%.2f", tarifa) + "]";
    }
    */
}