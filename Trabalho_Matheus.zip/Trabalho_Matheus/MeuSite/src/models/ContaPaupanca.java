package models;

import exceptions.SaldoInsuficienteException;
import exceptions.ValorInvalidoException;
import interfaces.Tributavel; // Importa a interface

/**
 * Representa uma Conta Poupança, que é um tipo de Conta Bancária.
 * Permite a aplicação de rendimento mensal e implementa a interface Tributavel.
 */
public class ContaPoupanca extends ContaBancaria implements Tributavel {

    // Atributo estático para o rendimento mensal (em porcentagem).
    // Exemplo: 0.5% ao mês.
    private static double rendimentoMensal = 0.5; // 0.5%

    /**
     * Construtor da Conta Poupança.
     * Repassa os dados básicos para o construtor da classe mãe (ContaBancaria).
     *
     * @param titular Nome do titular da conta.
     * @param conta Número da conta.
     * @param agencia Número da agência.
     * @param senha Senha da conta.
     */
    public ContaPoupanca(String titular, String conta, String agencia, String senha) {
        super(titular, conta, agencia, senha); // Chama o construtor da ContaBancaria
    }

    // --- Getter e Setter para o rendimento mensal estático ---

    public static double getRendimentoMensal() {
        return rendimentoMensal;
    }

    public static void setRendimentoMensal(double novoRendimento) {
        if (novoRendimento >= 0) {
            ContaPoupanca.rendimentoMensal = novoRendimento;
        } else {
            System.out.println("Erro: Rendimento mensal não pode ser negativo.");
        }
    }

    // --- Métodos Específicos da Conta Poupança ---

    /**
     * Aplica o rendimento mensal ao saldo da conta, com base na taxa estática.
     */
    public void aplicarRendimentoMensal() {
        if (getSaldo() > 0) { // Aplica rendimento apenas se o saldo for positivo
            double rendimentoCalculado = getSaldo() * (rendimentoMensal / 100.0);
            // Usando o método depositar para adicionar o rendimento (ou setSaldo diretamente)
            // setSaldo(getSaldo() + rendimentoCalculado); // Alternativa
            try {
                 // Usar depositar pode ser semanticamente estranho para rendimento,
                 // mas reutiliza a lógica de adição ao saldo.
                 // Vamos usar setSaldo que parece mais apropriado aqui.
                 setSaldo(getSaldo() + rendimentoCalculado);
                 System.out.println("Rendimento mensal de R$" + String.format("%.2f", rendimentoCalculado) +
                                   " ( " + rendimentoMensal + "%) aplicado.");
                 System.out.println("Novo saldo: R$" + String.format("%.2f", getSaldo()));
            } catch (Exception e) {
                // Exceção inesperada ao tentar adicionar rendimento (improvável com setSaldo)
                 System.err.println("Erro inesperado ao aplicar rendimento: " + e.getMessage());
            }
        } else {
             System.out.println("Saldo não positivo, rendimento mensal não aplicado.");
        }
    }

    // --- Implementação dos Métodos Abstratos e da Interface ---

    /**
     * Sobrescreve o método sacar da ContaBancaria.
     * Na conta poupança simples (sem taxa específica mencionada), apenas valida valor e saldo.
     *
     * @param valor O valor que o cliente deseja sacar.
     * @throws SaldoInsuficienteException Se o saldo não for suficiente para cobrir o valor do saque.
     * @throws ValorInvalidoException Se o valor do saque for negativo ou zero.
     */
    @Override
    public void sacar(double valor) throws SaldoInsuficienteException, ValorInvalidoException {
        // 1. Validar o valor do saque
        if (valor <= 0) {
            throw new ValorInvalidoException("Valor de saque inválido (R$" + String.format("%.2f", valor) + "). Deve ser maior que zero.");
        }

        // 2. Verificar se há saldo suficiente (sem taxa adicional neste caso)
        if (valor > getSaldo()) {
            throw new SaldoInsuficienteException(getSaldo(), valor); // Usa construtor informativo
        }

        // 3. Realizar o saque (atualizar o saldo)
        setSaldo(getSaldo() - valor);

        // 4. Imprimir confirmação
        System.out.println("Saque de R$" + String.format("%.2f", valor) + " realizado com sucesso da Conta Poupança.");
        // System.out.println("Novo saldo: R$" + String.format("%.2f", getSaldo()));
    }

    /**
     * Calcula o Imposto de Renda devido sobre a conta poupança.
     * Lógica de exemplo: 1% sobre o saldo atual (simplificado).
     * O requisito não especificou a base de cálculo.
     *
     * @return O valor do imposto calculado.
     */
    @Override
    public double calculaIR() {
        double imposto = getSaldo() * 0.01; // Exemplo: 1% sobre o saldo total
        System.out.println("Cálculo de IR (Exemplo: 1% sobre saldo) para Conta Poupança " + getConta() + ": R$" + String.format("%.2f", imposto));
        return imposto;
    }

     // toString() herdado de ContaBancaria. Pode adicionar info de rendimento se desejar.
    /*
    @Override
    public String toString() {
         return super.toString() + " [Rendimento Padrão CP: " + rendimentoMensal + "%]";
    }
    */
}