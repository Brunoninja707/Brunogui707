package models;

// Importando as exceções personalizadas (assumindo que estão no pacote 'exceptions')
import exceptions.SaldoInsuficienteException;
import exceptions.ValorInvalidoException;

// Importando a classe Pessoa (se o titular for do tipo Pessoa)
// import models.Pessoa; // Descomente se for usar Pessoa como titular


/**
 * Representa uma conta bancária genérica.
 * É uma classe abstrata, pois não se pode criar uma "ContaBancária" genérica,
 * mas sim tipos específicos como ContaCorrente ou ContaPoupanca.
 */
public abstract class ContaBancaria {

    // Atributos
    // Usando 'private' para melhor encapsulamento.
    // O acesso será feito via getters/setters.
    // private Pessoa titular; // Idealmente, o titular seria um objeto Pessoa
    private String titular; // Usando String conforme listado de forma simples no PDF
    private double saldo;
    private String conta;
    private String agencia;
    private String senha; // Cuidado com o armazenamento e acesso de senhas em sistemas reais

    // Construtor
    public ContaBancaria(String titular, String conta, String agencia, String senha) {
        // this.titular = titular; // Se titular fosse Pessoa
        this.titular = titular;
        this.conta = conta;
        this.agencia = agencia;
        this.senha = senha;
        this.saldo = 0.0; // Saldo inicial é zero
    }

    // --- Getters ---

    public String getTitular() {
        return titular;
    }

    public double getSaldo() {
        return saldo;
    }

    public String getConta() {
        return conta;
    }

    public String getAgencia() {
        return agencia;
    }

    // Getter para senha - Usar com cautela
    public String getSenha() {
        // Em um sistema real, você não retornaria a senha diretamente.
        // Poderia ter um método para verificar a senha, por exemplo.
        return senha;
    }

    // --- Setters ---
    // Permitir alterar o titular (ex: em caso de transferência de titularidade)
    public void setTitular(String titular) {
        this.titular = titular;
    }

    // Permitir alterar a senha
    public void setSenha(String senha) {
        // Adicionar validação de complexidade de senha aqui se necessário
        this.senha = senha;
    }

    // O saldo não deve ter um setter público, é modificado por depositar/sacar.
    // Conta e agência geralmente não mudam, então podem não ter setters.

    // --- Métodos Comuns ---

    /**
     * Deposita um valor na conta bancária.
     * O valor deve ser positivo.
     *
     * @param valor O valor a ser depositado. Deve ser maior que zero.
     * @throws ValorInvalidoException Se o valor do depósito for inválido (ex: negativo ou zero).
     */
    public void depositar(double valor) throws ValorInvalidoException {
        if (valor > 0) {
            this.saldo += valor;
            System.out.println("Depósito de R$" + String.format("%.2f", valor) + " realizado com sucesso.");
        } else {
            // Lançando a exceção personalizada
            throw new ValorInvalidoException("Valor de depósito inválido (R$" + String.format("%.2f", valor) + "). Deve ser maior que zero.");
        }
    }

    /**
     * Exibe o saldo atual da conta.
     */
    public void exibirSaldo() {
        System.out.println("---------------------------");
        System.out.println("Conta: " + this.agencia + " / " + this.conta);
        System.out.println("Titular: " + this.titular);
        System.out.println("Saldo Atual: R$" + String.format("%.2f", this.saldo));
        System.out.println("---------------------------");
    }


    // --- Método Abstrato ---

    /**
     * Realiza um saque da conta bancária.
     * A implementação específica (ex: cobrança de taxas) deve ser feita pelas subclasses.
     * As subclasses devem validar o valor e o saldo disponível.
     *
     * @param valor O valor a ser sacado.
     * @throws SaldoInsuficienteException Se o saldo for insuficiente para o saque (considerando taxas).
     * @throws ValorInvalidoException Se o valor do saque for inválido (ex: negativo ou zero).
     */
    public abstract void sacar(double valor) throws SaldoInsuficienteException, ValorInvalidoException;

    // (Opcional) Método protegido para que subclasses possam alterar o saldo diretamente ao sacar
    // Alternativa a ter um setter público para saldo. Use com cuidado.
    protected void setSaldo(double novoSaldo) {
        this.saldo = novoSaldo;
    }

    // (Opcional) Sobrescrever toString() pode ser útil
    @Override
    public String toString() {
        // Ajustado para não incluir a senha na representação padrão
        return this.getClass().getSimpleName() + "{" + // Mostra o nome da classe concreta (CC ou CP)
               "titular='" + titular + '\'' +
               ", agencia='" + agencia + '\'' +
               ", conta='" + conta + '\'' +
               ", saldo=" + String.format("%.2f", saldo) +
               '}';
    }
}