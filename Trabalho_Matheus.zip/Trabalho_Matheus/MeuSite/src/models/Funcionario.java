package models;

import interfaces.Tributavel; // Importa a interface

/**
 * Representa um Funcionário, que é um tipo de Pessoa.
 * Possui cargo, salário, uma conta salário e implementa Tributavel.
 */
public class Funcionario extends Pessoa implements Tributavel {

    private String cargo;
    private double salario;
    private ContaBancaria contaSalario; // Composição: Funcionário TEM UMA ContaBancaria

    /**
     * Construtor do Funcionário.
     *
     * @param nome Nome do funcionário (herdado de Pessoa).
     * @param idade Idade do funcionário (herdado de Pessoa).
     * @param endereco Endereço do funcionário (herdado de Pessoa).
     * @param cpf CPF do funcionário (herdado de Pessoa).
     * @param cargo Cargo do funcionário.
     * @param salario Salário base do funcionário.
     * @param contaSalario A conta bancária associada para depósito do salário.
     */
    public Funcionario(String nome, int idade, String endereco, String cpf,
                       String cargo, double salario, ContaBancaria contaSalario) {
        super(nome, idade, endereco, cpf); // Chama o construtor da classe Pessoa
        this.cargo = cargo;
        setSalario(salario); // Usa o setter para validação
        this.contaSalario = contaSalario; // Associa a conta recebida
    }

    // --- Getters ---

    public String getCargo() {
        return cargo;
    }

    public ContaBancaria getContaSalario() {
        return contaSalario;
    }

    // --- Setter para Salário (com validação) ---
     public void setSalario(double salario) {
        if (salario >= 0) { // Permitindo salário zero, mas não negativo
            this.salario = salario;
        } else {
            System.out.println("Erro: Salário não pode ser negativo.");
            // Considerar lançar IllegalArgumentException
            this.salario = 0; // Define como 0 em caso de erro
        }
    }

    // --- Métodos de Salário (conforme solicitado) ---

    /**
     * Retorna o salário base do funcionário.
     * @return O salário base.
     */
    public double getSalario() {
        return this.salario;
    }

    /**
     * Calcula e retorna o salário com um bônus adicional. (Sobrecarga)
     * @param bonus O valor do bônus a ser adicionado.
     * @return O salário base mais o bônus. Retorna apenas o salário base se o bônus for negativo.
     */
    public double getSalario(double bonus) {
        if (bonus >= 0) {
            return this.salario + bonus;
        } else {
            System.out.println("Aviso: Bônus inválido (negativo), retornando apenas o salário base.");
            return this.salario;
        }
    }

    // --- Implementação da Interface Tributavel ---

    /**
     * Calcula o Imposto de Renda devido pelo funcionário.
     * Lógica de exemplo: 15% sobre o salário base (simplificado).
     *
     * @return O valor do imposto calculado.
     */
    @Override
    public double calculaIR() {
        double imposto = this.salario * 0.15; // Exemplo: 15% sobre o salário base
        System.out.println("Cálculo de IR (Exemplo: 15% sobre salário) para Funcionário " + getNome() + ": R$" + String.format("%.2f", imposto));
        return imposto;
    }

    // --- Sobrescrita do Método exibirInformacoes ---

    /**
     * Sobrescreve o método de Pessoa para incluir informações do funcionário.
     */
    @Override
    public void exibirInformacoes() {
        System.out.println("--- Informações do Funcionário ---");
        System.out.println("Nome: " + getNome());
        System.out.println("Idade: " + getIdade());
        System.out.println("Endereço: " + getEndereco());
        System.out.println("CPF: " + getCpf());
        System.out.println("Cargo: " + this.cargo);
        System.out.println("Salário Base: R$" + String.format("%.2f", this.salario));
        if (this.contaSalario != null) {
            System.out.println("Conta Salário: Agência " + this.contaSalario.getAgencia() +
                               " / Conta " + this.contaSalario.getConta());
        } else {
             System.out.println("Conta Salário: Não definida.");
        }
        System.out.println("--------------------------------");
    }

     // --- toString() (Opcional) ---
    @Override
    public String toString() {
        return "Funcionario{" +
               "cpf='" + getCpf() + '\'' + // Herdado
               ", nome='" + getNome() + '\'' + // Herdado
               ", cargo='" + cargo + '\'' +
               ", salario=" + String.format("%.2f", salario) +
               ", contaSalario=" + (contaSalario != null ? contaSalario.getConta() : "N/A") +
               '}';
    }
}