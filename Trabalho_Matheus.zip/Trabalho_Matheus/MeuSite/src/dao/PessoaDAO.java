// src/dao/PessoaDAO.java
package dao;

import models.Pessoa;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface PessoaDAO {
    void salvar(Pessoa pessoa) throws SQLException;
    Optional<Pessoa> buscarPorCpf(String cpf) throws SQLException;
    List<Pessoa> listarTodos() throws SQLException;
    void atualizar(Pessoa pessoa) throws SQLException;
    void deletar(String cpf) throws SQLException;
}

// --------------------------------------------------

// src/dao/ContaBancariaDAO.java
package dao;

import models.ContaBancaria;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface ContaBancariaDAO {
    long salvar(ContaBancaria conta) throws SQLException;
    Optional<ContaBancaria> buscarPorId(long id) throws SQLException;
    Optional<ContaBancaria> buscarPorNumeroConta(String numeroConta) throws SQLException;
    List<ContaBancaria> listarTodas() throws SQLException;
    List<ContaBancaria> listarPorTitularCpf(String cpf) throws SQLException;
    void atualizar(ContaBancaria conta) throws SQLException;
    void deletar(long id) throws SQLException;
}

// --------------------------------------------------

// src/dao/FuncionarioDAO.java
package dao;

import models.Funcionario;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface FuncionarioDAO {
    void salvar(Funcionario funcionario) throws SQLException;
    Optional<Funcionario> buscarPorCpf(String cpf) throws SQLException;
    List<Funcionario> listarTodos() throws SQLException;
    List<Funcionario> listarPorEmpresa(String cnpj) throws SQLException;
    void atualizar(Funcionario funcionario) throws SQLException;
    void deletar(String cpf) throws SQLException;
}

// --------------------------------------------------

// src/dao/ProdutoDAO.java
package dao;

import models.Produto;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface ProdutoDAO {
    int salvar(Produto produto) throws SQLException;
    Optional<Produto> buscarPorCodigo(int codigo) throws SQLException;
    List<Produto> listarTodos() throws SQLException;
    List<Produto> listarPorEmpresa(String cnpj) throws SQLException;
    List<Produto> buscarPorNome(String nomeParcial) throws SQLException;
    List<Produto> buscarPorPreco(double min, double max) throws SQLException;
    void atualizar(Produto produto) throws SQLException;
    void deletar(int codigo) throws SQLException;
}


// --------------------------------------------------

// src/dao/EmpresaDAO.java
package dao;

import models.Empresa;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface EmpresaDAO {
    void salvar(Empresa empresa) throws SQLException;
    Optional<Empresa> buscarPorCnpj(String cnpj) throws SQLException;
    List<Empresa> listarTodas() throws SQLException;
    void atualizar(Empresa empresa) throws SQLException;
    void deletar(String cnpj) throws SQLException;
    void adicionarEmail(String cnpj, String email) throws SQLException;
    void removerEmail(String cnpj, String email) throws SQLException;
    List<String> listarEmails(String cnpj) throws SQLException;
}