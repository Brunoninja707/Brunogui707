package dao;

import models.Empresa;
import models.Funcionario; // Import if needed for complex load
import models.Produto;    // Import if needed for complex load
import util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class EmpresaDAOImpl implements EmpresaDAO {

     // Optional: Inject DAOs if loading full Empresa object later
     // private FuncionarioDAO funcionarioDAO = new FuncionarioDAOImpl();
     // private ProdutoDAO produtoDAO = new ProdutoDAOImpl();

    @Override
    public void salvar(Empresa empresa) throws SQLException {
         String sqlEmpresa = "INSERT INTO empresas (cnpj, nome) VALUES (?, ?) " +
                             "ON CONFLICT (cnpj) DO UPDATE SET nome = EXCLUDED.nome";
        Connection conn = null;
        PreparedStatement pstmtEmpresa = null;

        try {
            conn = ConnectionFactory.getConnection();
            conn.setAutoCommit(false); // Start transaction

            pstmtEmpresa = conn.prepareStatement(sqlEmpresa);
            pstmtEmpresa.setString(1, empresa.getCnpj());
            pstmtEmpresa.setString(2, empresa.getNome());
            pstmtEmpresa.executeUpdate();
            System.out.println("Empresa salva/atualizada: " + empresa.getCnpj());

            // Clear existing emails for this company before adding current ones
            String sqlDeleteEmails = "DELETE FROM empresa_emails WHERE empresa_cnpj = ?";
            try (PreparedStatement pstmtDel = conn.prepareStatement(sqlDeleteEmails)) {
                pstmtDel.setString(1, empresa.getCnpj());
                pstmtDel.executeUpdate();
            }

            // Add current emails
            if (empresa.getEmails() != null && !empresa.getEmails().isEmpty()) {
                 String sqlAddEmail = "INSERT INTO empresa_emails (empresa_cnpj, email) VALUES (?, ?)";
                 try(PreparedStatement pstmtAddEmail = conn.prepareStatement(sqlAddEmail)) {
                     for (String email : empresa.getEmails()) {
                         pstmtAddEmail.setString(1, empresa.getCnpj());
                         pstmtAddEmail.setString(2, email);
                         pstmtAddEmail.addBatch(); // Add to batch for efficiency
                     }
                     pstmtAddEmail.executeBatch(); // Execute all inserts
                     System.out.println("Emails da empresa atualizados: " + empresa.getCnpj());
                 }
            }

            conn.commit(); // Commit transaction

        } catch (SQLException e) {
            if (conn != null) try { conn.rollback(); } catch (SQLException ex) { System.err.println("Erro no rollback: "+ex.getMessage());}
            System.err.println("Erro ao salvar empresa e emails: " + e.getMessage());
            throw e; // Re-throw exception after rollback
        } finally {
            if (conn != null) try { conn.setAutoCommit(true); } catch (SQLException ex) {} // Reset autoCommit
             ConnectionFactory.close(conn, pstmtEmpresa); // Close resources
        }
    }


    @Override
    public Optional<Empresa> buscarPorCnpj(String cnpj) throws SQLException {
        String sql = "SELECT cnpj, nome FROM empresas WHERE cnpj = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Empresa empresa = null;

        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cnpj);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                String nome = rs.getString("nome");
                empresa = new Empresa(nome, cnpj); // Create basic company object

                // Fetch associated emails
                List<String> emails = listarEmails(cnpj, conn); // Use existing connection
                for(String email : emails) {
                    empresa.adicionarEmail(email); // Use the model's method to add
                }

                // NOTE: Loading funcionario/produto lists is intentionally omitted here
                // for simplicity. It would require separate calls to their DAOs.
            }
        } finally {
            ConnectionFactory.close(null, pstmt, rs); // Only close statement and resultset
             if(conn != null) ConnectionFactory.closeConnection(conn); // Close connection separately
        }
        return Optional.ofNullable(empresa);
    }

    @Override
    public List<Empresa> listarTodas() throws SQLException {
         List<Empresa> empresas = new ArrayList<>();
         String sql = "SELECT cnpj, nome FROM empresas";
         Connection conn = null;
         Statement stmt = null;
         ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                 // Creates basic Empresa object without emails/lists for performance
                 empresas.add(new Empresa(rs.getString("nome"), rs.getString("cnpj")));
            }
        } finally {
            ConnectionFactory.close(conn, stmt, rs);
        }
        return empresas;
    }

    @Override
    public void atualizar(Empresa empresa) throws SQLException {
        // This method primarily updates the company's name.
        // Email management is handled by salvar() or specific add/remove methods.
        String sql = "UPDATE empresas SET nome = ? WHERE cnpj = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, empresa.getNome());
            pstmt.setString(2, empresa.getCnpj());
            int affectedRows = pstmt.executeUpdate();
             if (affectedRows > 0) {
                 System.out.println("Nome da empresa atualizado com sucesso: " + empresa.getCnpj());
             } else {
                 System.out.println("Nenhuma empresa encontrada com o CNPJ para atualizar: " + empresa.getCnpj());
             }
             // Optional: If you want 'atualizar' to also sync emails, call salvar() instead.
        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }


    @Override
    public void deletar(String cnpj) throws SQLException {
         String sql = "DELETE FROM empresas WHERE cnpj = ?";
         Connection conn = null;
         PreparedStatement pstmt = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cnpj);
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                 System.out.println("Empresa deletada com sucesso (e dados associados via CASCADE): " + cnpj);
             } else {
                 System.out.println("Nenhuma empresa encontrada com o CNPJ para deletar: " + cnpj);
             }
             // Cascade constraints in schema handle deletion of related emails, funcionarios, produtos
        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }

     @Override
    public void adicionarEmail(String cnpj, String email) throws SQLException {
        String sql = "INSERT INTO empresa_emails (empresa_cnpj, email) VALUES (?, ?) ON CONFLICT DO NOTHING";
         Connection conn = null;
         PreparedStatement pstmt = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cnpj);
            pstmt.setString(2, email);
            pstmt.executeUpdate();
            System.out.println("Tentativa de adicionar email " + email + " para empresa " + cnpj);
        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }

    @Override
    public void removerEmail(String cnpj, String email) throws SQLException {
         String sql = "DELETE FROM empresa_emails WHERE empresa_cnpj = ? AND email = ?";
         Connection conn = null;
         PreparedStatement pstmt = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cnpj);
            pstmt.setString(2, email);
             int affectedRows = pstmt.executeUpdate();
             if (affectedRows > 0) {
                 System.out.println("Email removido: " + email + " da empresa " + cnpj);
             } else {
                 System.out.println("Email não encontrado para remover: " + email + " da empresa " + cnpj);
             }
        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }

    @Override
    public List<String> listarEmails(String cnpj) throws SQLException {
        return listarEmails(cnpj, null); // Call helper with null connection to create a new one
    }


     // Helper to list emails, optionally reusing a connection
    private List<String> listarEmails(String cnpj, Connection existingConn) throws SQLException {
         List<String> emails = new ArrayList<>();
         String sql = "SELECT email FROM empresa_emails WHERE empresa_cnpj = ?";
         Connection conn = null;
         PreparedStatement pstmt = null;
         ResultSet rs = null;
         boolean closeConn = false; // Flag to know if we need to close the connection

         try {
            if (existingConn == null || existingConn.isClosed()) {
                 conn = ConnectionFactory.getConnection();
                 closeConn = true; // We opened it, we close it
            } else {
                conn = existingConn; // Reuse existing connection
            }

            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cnpj);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                emails.add(rs.getString("email"));
            }
        } finally {
             // Close resultset and statement always
            if (rs != null) try { rs.close(); } catch (SQLException e) {}
            if (pstmt != null) try { pstmt.close(); } catch (SQLException e) {}
             // Close connection only if we opened it in this method
             if (closeConn && conn != null) {
                 ConnectionFactory.closeConnection(conn);
             }
        }
        return emails;
    }
}