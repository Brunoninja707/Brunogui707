package dao;

import models.Produto;
import util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProdutoDAOImpl implements ProdutoDAO {

    @Override
    public int salvar(Produto produto) throws SQLException {
        String sql = "INSERT INTO produtos (codigo, nome, valor, quantidade, empresa_cnpj) VALUES (?, ?, ?, ?, ?) " +
                     "ON CONFLICT (codigo) DO UPDATE SET " +
                     "nome = EXCLUDED.nome, valor = EXCLUDED.valor, quantidade = EXCLUDED.quantidade, empresa_cnpj = EXCLUDED.empresa_cnpj " +
                     "RETURNING codigo";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int codigoSalvo = -1;

        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);

            // Se o código for 0 ou não definido, pode indicar auto-incremento (ajustar SQL se necessário)
            // Aqui assumimos que o código é fornecido ou gerenciado pelo banco (SERIAL)
            if (produto.getCodigo() > 0) {
                 pstmt.setInt(1, produto.getCodigo());
            } else {
                 // Se for SERIAL, o banco gera. O SQL pode precisar ser ajustado para não incluir codigo no INSERT inicial.
                 // Exemplo simplificado assumindo que codigo > 0 é fornecido
                 throw new SQLException("Código do produto inválido ou não fornecido para salvar.");
            }

            pstmt.setString(2, produto.getNome());
            pstmt.setDouble(3, produto.getValor());
            pstmt.setInt(4, produto.getQuantidade());

             // Assumindo que produto tem uma referencia à empresa ou cnpj
            // pstmt.setString(5, produto.getEmpresaCnpj()); // Exemplo
            pstmt.setNull(5, Types.VARCHAR); // Definindo nulo por enquanto

            rs = pstmt.executeQuery(); // Use executeQuery para obter o RETURNING

            if (rs.next()) {
                codigoSalvo = rs.getInt(1);
                System.out.println("Produto salvo/atualizado com sucesso: " + codigoSalvo);
            } else {
                 // Pode acontecer se ON CONFLICT não retornar nada ou erro
                 System.err.println("Falha ao salvar/atualizar produto, nenhum código retornado.");
            }

        } finally {
            ConnectionFactory.close(conn, pstmt, rs);
        }
        return codigoSalvo;
    }

    @Override
    public Optional<Produto> buscarPorCodigo(int codigo) throws SQLException {
        String sql = "SELECT codigo, nome, valor, quantidade, empresa_cnpj FROM produtos WHERE codigo = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, codigo);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return Optional.of(mapRowToProduto(rs));
            }
        } finally {
            ConnectionFactory.close(conn, pstmt, rs);
        }
        return Optional.empty();
    }

    @Override
    public List<Produto> listarTodos() throws SQLException {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT codigo, nome, valor, quantidade, empresa_cnpj FROM produtos";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                produtos.add(mapRowToProduto(rs));
            }
        } finally {
            ConnectionFactory.close(conn, stmt, rs);
        }
        return produtos;
    }

    @Override
    public List<Produto> listarPorEmpresa(String cnpj) throws SQLException {
         List<Produto> produtos = new ArrayList<>();
         String sql = "SELECT codigo, nome, valor, quantidade, empresa_cnpj FROM produtos WHERE empresa_cnpj = ?";
         Connection conn = null;
         PreparedStatement pstmt = null;
         ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cnpj);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                produtos.add(mapRowToProduto(rs));
            }
        } finally {
            ConnectionFactory.close(conn, pstmt, rs);
        }
        return produtos;
    }

    @Override
    public List<Produto> buscarPorNome(String nomeParcial) throws SQLException {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT codigo, nome, valor, quantidade, empresa_cnpj FROM produtos WHERE nome ILIKE ?"; // ILIKE for PostgreSQL case-insensitive
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + nomeParcial + "%");
            rs = pstmt.executeQuery();
            while (rs.next()) {
                produtos.add(mapRowToProduto(rs));
            }
        } finally {
            ConnectionFactory.close(conn, pstmt, rs);
        }
        return produtos;
    }

     @Override
    public List<Produto> buscarPorPreco(double min, double max) throws SQLException {
         List<Produto> produtos = new ArrayList<>();
         String sql = "SELECT codigo, nome, valor, quantidade, empresa_cnpj FROM produtos WHERE valor BETWEEN ? AND ?";
         Connection conn = null;
         PreparedStatement pstmt = null;
         ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setDouble(1, min);
            pstmt.setDouble(2, max);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                produtos.add(mapRowToProduto(rs));
            }
        } finally {
            ConnectionFactory.close(conn, pstmt, rs);
        }
        return produtos;
    }

    @Override
    public void atualizar(Produto produto) throws SQLException {
        String sql = "UPDATE produtos SET nome = ?, valor = ?, quantidade = ?, empresa_cnpj = ? WHERE codigo = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, produto.getNome());
            pstmt.setDouble(2, produto.getValor());
            pstmt.setInt(3, produto.getQuantidade());
             // pstmt.setString(4, produto.getEmpresaCnpj()); // Se existir
            pstmt.setNull(4, Types.VARCHAR);
            pstmt.setInt(5, produto.getCodigo());

            int affectedRows = pstmt.executeUpdate();
             if (affectedRows > 0) {
                 System.out.println("Produto atualizado com sucesso: " + produto.getCodigo());
             } else {
                 System.out.println("Nenhum produto encontrado com o código para atualizar: " + produto.getCodigo());
             }
        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }

    @Override
    public void deletar(int codigo) throws SQLException {
        String sql = "DELETE FROM produtos WHERE codigo = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, codigo);
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                 System.out.println("Produto deletado com sucesso: " + codigo);
             } else {
                 System.out.println("Nenhum produto encontrado com o código para deletar: " + codigo);
             }
        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }

    private Produto mapRowToProduto(ResultSet rs) throws SQLException {
        int codigo = rs.getInt("codigo");
        String nome = rs.getString("nome");
        double valor = rs.getDouble("valor");
        int quantidade = rs.getInt("quantidade");
        // String empresaCnpj = rs.getString("empresa_cnpj"); // Se precisar

        Produto prod = new Produto(codigo, nome, valor, quantidade);
        // prod.setEmpresaCnpj(empresaCnpj); // Se existir no modelo
        return prod;
    }
}