package dao;

import models.ContaBancaria;
import models.ContaCorrente;
import models.ContaPoupanca;
import models.Funcionario;
import models.Pessoa;
import util.ConnectionFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class FuncionarioDAOImpl implements FuncionarioDAO {

    private final PessoaDAO pessoaDAO = new PessoaDAOImpl();
    private final ContaBancariaDAO contaBancariaDAO = new ContaBancariaDAOImpl();

    @Override
    public void salvar(Funcionario funcionario) throws SQLException {
        Optional<Pessoa> pessoaOpt = pessoaDAO.buscarPorCpf(funcionario.getCpf());
        if (pessoaOpt.isEmpty()) {
            pessoaDAO.salvar(funcionario);
        } else {
            pessoaDAO.atualizar(funcionario);
        }

        String sql = "INSERT INTO funcionarios (cpf, cargo, salario, conta_salario_id, empresa_cnpj) " +
                     "VALUES (?, ?, ?, ?, ?) " +
                     "ON CONFLICT (cpf) DO UPDATE SET " +
                     "cargo = EXCLUDED.cargo, salario = EXCLUDED.salario, " +
                     "conta_salario_id = EXCLUDED.conta_salario_id, empresa_cnpj = EXCLUDED.empresa_cnpj";

        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);

            pstmt.setString(1, funcionario.getCpf());
            pstmt.setString(2, funcionario.getCargo());
            pstmt.setDouble(3, funcionario.getSalario());

            if (funcionario.getContaSalario() != null) {
                // Tentativa de obter ID da conta - simplificado
                // Idealmente, a conta já teria um ID se foi salva/recuperada
                Optional<ContaBancaria> contaOpt = contaBancariaDAO.buscarPorNumeroConta(funcionario.getContaSalario().getConta());
                if(contaOpt.isPresent()){
                     // Supondo um método getId() em ContaBancaria após mapeamento
                     // pstmt.setLong(4, contaOpt.get().getId());
                     // Solução alternativa: buscar ID por numero e agencia
                      pstmt.setLong(4, buscarIdContaPorNumeroAgencia(funcionario.getContaSalario().getConta(), funcionario.getContaSalario().getAgencia()));

                } else {
                     // Se a conta não existe, salva-a primeiro
                     long idConta = contaBancariaDAO.salvar(funcionario.getContaSalario());
                     if(idConta != -1){
                         pstmt.setLong(4, idConta);
                     } else {
                          pstmt.setNull(4, Types.BIGINT); // Falha ao salvar conta
                     }
                }
            } else {
                pstmt.setNull(4, Types.BIGINT);
            }

            // Assumindo que funcionario tem uma referencia à empresa ou cnpj
            // Se Funcionario não tiver empresa_cnpj, esta lógica precisa ser ajustada
            // pstmt.setString(5, funcionario.getEmpresaCnpj()); // Exemplo
            pstmt.setNull(5, Types.VARCHAR); // Definindo nulo por enquanto

            pstmt.executeUpdate();
            System.out.println("Funcionário salvo/atualizado com sucesso: " + funcionario.getCpf());

        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }
     // Método auxiliar (exemplo) - pode precisar de mais robustez
    private long buscarIdContaPorNumeroAgencia(String numero, String agencia) throws SQLException {
         String sql = "SELECT id FROM contas_bancarias WHERE numero_conta = ? AND agencia = ?";
         try (Connection conn = ConnectionFactory.getConnection();
              PreparedStatement pstmt = conn.prepareStatement(sql)) {
             pstmt.setString(1, numero);
             pstmt.setString(2, agencia);
             try (ResultSet rs = pstmt.executeQuery()) {
                 if (rs.next()) {
                     return rs.getLong("id");
                 }
             }
         }
         return -1; // Não encontrado
     }


    @Override
    public Optional<Funcionario> buscarPorCpf(String cpf) throws SQLException {
        String sql = "SELECT p.nome, p.idade, p.endereco, f.cpf, f.cargo, f.salario, f.empresa_cnpj, f.conta_salario_id " +
                     "FROM funcionarios f JOIN pessoas p ON f.cpf = p.cpf " +
                     "WHERE f.cpf = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cpf);
            rs = pstmt.executeQuery();
            if (rs.next()) {
                return Optional.of(mapRowToFuncionario(rs));
            }
        } finally {
            ConnectionFactory.close(conn, pstmt, rs);
        }
        return Optional.empty();
    }

    @Override
    public List<Funcionario> listarTodos() throws SQLException {
        List<Funcionario> funcionarios = new ArrayList<>();
        String sql = "SELECT p.nome, p.idade, p.endereco, f.cpf, f.cargo, f.salario, f.empresa_cnpj, f.conta_salario_id " +
                     "FROM funcionarios f JOIN pessoas p ON f.cpf = p.cpf";
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery(sql);
            while (rs.next()) {
                funcionarios.add(mapRowToFuncionario(rs));
            }
        } finally {
            ConnectionFactory.close(conn, stmt, rs);
        }
        return funcionarios;
    }

    @Override
    public List<Funcionario> listarPorEmpresa(String cnpj) throws SQLException {
        List<Funcionario> funcionarios = new ArrayList<>();
         String sql = "SELECT p.nome, p.idade, p.endereco, f.cpf, f.cargo, f.salario, f.empresa_cnpj, f.conta_salario_id " +
                      "FROM funcionarios f JOIN pessoas p ON f.cpf = p.cpf " +
                      "WHERE f.empresa_cnpj = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cnpj);
            rs = pstmt.executeQuery();
            while (rs.next()) {
                funcionarios.add(mapRowToFuncionario(rs));
            }
        } finally {
            ConnectionFactory.close(conn, pstmt, rs);
        }
        return funcionarios;
    }


    @Override
    public void atualizar(Funcionario funcionario) throws SQLException {
        pessoaDAO.atualizar(funcionario);

        String sql = "UPDATE funcionarios SET cargo = ?, salario = ?, conta_salario_id = ?, empresa_cnpj = ? WHERE cpf = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, funcionario.getCargo());
            pstmt.setDouble(2, funcionario.getSalario());

             if (funcionario.getContaSalario() != null) {
                  long contaId = buscarIdContaPorNumeroAgencia(funcionario.getContaSalario().getConta(), funcionario.getContaSalario().getAgencia());
                   if(contaId != -1){
                        pstmt.setLong(3, contaId);
                   } else {
                        // Opção: Tentar salvar a conta se não existir? Ou lançar erro?
                        pstmt.setNull(3, Types.BIGINT);
                   }
             } else {
                 pstmt.setNull(3, Types.BIGINT);
             }

             // pstmt.setString(4, funcionario.getEmpresaCnpj()); // Se existir no modelo
              pstmt.setNull(4, Types.VARCHAR);
              pstmt.setString(5, funcionario.getCpf());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                System.out.println("Nenhum funcionário encontrado com o CPF para atualizar: " + funcionario.getCpf());
            } else {
                System.out.println("Funcionário atualizado com sucesso: " + funcionario.getCpf());
            }
        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }

    @Override
    public void deletar(String cpf) throws SQLException {
        String sql = "DELETE FROM funcionarios WHERE cpf = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = ConnectionFactory.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, cpf);
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Funcionário deletado com sucesso: " + cpf);
            } else {
                System.out.println("Nenhum funcionário encontrado com o CPF para deletar: " + cpf);
            }
        } finally {
            ConnectionFactory.close(conn, pstmt);
        }
    }

    private Funcionario mapRowToFuncionario(ResultSet rs) throws SQLException {
        String cpf = rs.getString("cpf");
        String nome = rs.getString("nome");
        int idade = rs.getInt("idade");
        String endereco = rs.getString("endereco");
        String cargo = rs.getString("cargo");
        double salario = rs.getDouble("salario");
        long contaSalarioId = rs.getLong("conta_salario_id");
        // String empresaCnpj = rs.getString("empresa_cnpj"); // Se precisar

        ContaBancaria conta = null;
        if (!rs.wasNull()) {
           Optional<ContaBancaria> contaOpt = contaBancariaDAO.buscarPorId(contaSalarioId);
           if(contaOpt.isPresent()){
               conta = contaOpt.get();
           }
        }

        Funcionario func = new Funcionario(nome, idade, endereco, cpf, cargo, salario, conta);
        // func.setEmpresaCnpj(empresaCnpj); // Se existir no modelo
        return func;
    }
}