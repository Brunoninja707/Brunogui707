DROP TABLE IF EXISTS empresa_emails CASCADE;
DROP TABLE IF EXISTS funcionarios CASCADE;
DROP TABLE IF EXISTS produtos CASCADE;
DROP TABLE IF EXISTS contas_bancarias CASCADE;
DROP TABLE IF EXISTS pessoas CASCADE;
DROP TABLE IF EXISTS empresas CASCADE;

CREATE TABLE pessoas (
    cpf VARCHAR(14) PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    idade INTEGER,
    endereco VARCHAR(500)
);

CREATE TABLE empresas (
    cnpj VARCHAR(18) PRIMARY KEY,
    nome VARCHAR(255) NOT NULL
);

CREATE TABLE contas_bancarias (
    id BIGSERIAL PRIMARY KEY,
    numero_conta VARCHAR(20) NOT NULL UNIQUE,
    agencia VARCHAR(10) NOT NULL,
    titular_cpf VARCHAR(14) NOT NULL,
    saldo NUMERIC(15, 2) DEFAULT 0.00,
    senha VARCHAR(255) NOT NULL,
    tipo_conta VARCHAR(20) NOT NULL,
    tarifa NUMERIC(10, 2),
    rendimento_mensal NUMERIC(5, 2),
    CONSTRAINT fk_conta_titular FOREIGN KEY (titular_cpf) REFERENCES pessoas(cpf) ON DELETE CASCADE
);

CREATE TABLE funcionarios (
    cpf VARCHAR(14) PRIMARY KEY,
    cargo VARCHAR(100),
    salario NUMERIC(15, 2),
    conta_salario_id BIGINT,
    empresa_cnpj VARCHAR(18),
    CONSTRAINT fk_funcionario_pessoa FOREIGN KEY (cpf) REFERENCES pessoas(cpf) ON DELETE CASCADE,
    CONSTRAINT fk_funcionario_conta FOREIGN KEY (conta_salario_id) REFERENCES contas_bancarias(id) ON DELETE SET NULL,
    CONSTRAINT fk_funcionario_empresa FOREIGN KEY (empresa_cnpj) REFERENCES empresas(cnpj) ON DELETE CASCADE
);

CREATE TABLE produtos (
    codigo SERIAL PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    valor NUMERIC(15, 2) NOT NULL,
    quantidade INTEGER DEFAULT 0,
    empresa_cnpj VARCHAR(18),
    CONSTRAINT fk_produto_empresa FOREIGN KEY (empresa_cnpj) REFERENCES empresas(cnpj) ON DELETE CASCADE
);

CREATE TABLE empresa_emails (
    empresa_cnpj VARCHAR(18) NOT NULL,
    email VARCHAR(255) NOT NULL,
    PRIMARY KEY (empresa_cnpj, email),
    CONSTRAINT fk_email_empresa FOREIGN KEY (empresa_cnpj) REFERENCES empresas(cnpj) ON DELETE CASCADE
);

CREATE INDEX idx_conta_titular ON contas_bancarias(titular_cpf);
CREATE INDEX idx_func_empresa ON funcionarios(empresa_cnpj);
CREATE INDEX idx_prod_empresa ON produtos(empresa_cnpj);